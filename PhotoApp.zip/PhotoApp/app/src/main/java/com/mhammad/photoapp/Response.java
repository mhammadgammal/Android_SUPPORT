package com.mhammad.photoapp;

import java.util.ArrayList;

public class Response {
public int taotal;
public int totalHits;
public ArrayList<Hit> hits;
}
