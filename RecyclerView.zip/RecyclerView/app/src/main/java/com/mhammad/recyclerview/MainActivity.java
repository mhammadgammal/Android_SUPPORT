package com.mhammad.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView car;
    Adapter adapter;
    List<DataSet> carsData =  new ArrayList<DataSet>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        car = findViewById(R.id.RecycView);
        dataSet();
        adapter = new Adapter(carsData);
        car.setAdapter(adapter);
        car.setLayoutManager(new LinearLayoutManager(this));

    }
    public void dataSet()
    {
        int[] images = {R.drawable.bmw_e36,
        R.drawable.volkswagen_golf,
        R.drawable.vw_passat,
        R.drawable.bmw_m5_e60,
        R.drawable.honda_civic,
        R.drawable.honda_accord,
        R.drawable.hyendai_tuscon,
        R.drawable.impreza,
        R.drawable.hyundai_elentra,
        R.drawable.lancer_evo};
        ////////////////////////////////////////

        String[] brands={
                "BMW",
        "VOLKS WAGEN",
        "VOLKS WAGEN",
        "BMW",
        "HONDA",
        "HONDA",
        "HYUNDAI",
        "SUBARU",
        "HYUNDAI",
        "MITSUBISHI"
        };
        ////////////////////////////////////////
        String[] Model ={
            "M3 e36",
            "Golf",
        "PASSAT",
        "M5 e60",
        "CIVIC",
        "ACCORD",
        "TUSCON",
        "IMPREZA",
        "ELENTRA",
        "LANCER Evo"
        };
        for(int i = 0;i<carsData.size();i++)
        {
            carsData.add(new DataSet(images[i], brands[i], Model[i]));
        }
    }
}