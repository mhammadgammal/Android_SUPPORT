package com.mhammad.recyclerview;

public class DataSet {
    int image;
    String brands, model;

    public DataSet(int image, String brands, String model) {
        this.image = image;
        this.brands = brands;
        this.model = model;
    }

    public int getImage() {
        return image;
    }

    public String getBrands() {
        return brands;
    }

    public String getModel() {
        return model;
    }
}
