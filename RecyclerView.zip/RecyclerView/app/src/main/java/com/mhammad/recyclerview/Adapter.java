package com.mhammad.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    List<DataSet> Cars;
    public Adapter(List<DataSet> Cars)
        {

            this.Cars = Cars;
        }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View ViewItem = LayoutInflater.from(parent.getContext()).inflate(R.layout.cars_list_item, parent, false);
        return new ViewHolder(ViewItem);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position){
        holder.logo.setImageResource(Cars.get(position).getImage());
        holder.brand.setText(Cars.get(position).getBrands());
        holder.category.setText(Cars.get(position).getModel());
    }

    @Override
    public int getItemCount() {
        return Cars.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView brand, category;
        ImageView logo;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            brand = itemView.findViewById(R.id.brand);
            category = itemView.findViewById(R.id.categorytxt);
            logo = itemView.findViewById(R.id.logo);
        }
    }
}
